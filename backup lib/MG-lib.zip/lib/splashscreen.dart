import 'package:flutter/material.dart';
import 'dart:async';
import 'StartScreen.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  double _opacity =
      0.0; // Initial opacity of the image is set to 0 (completely transparent)

  @override
  void initState() {
    super.initState();
    // Start the fade-in animation after 1 second
    Timer(Duration(seconds: 1), () {
      setState(() {
        _opacity = 1.0; // Change opacity to 1 to make the image fully visible
      });
    });

    // Navigate to the StartScreen after 3 seconds
    Timer(Duration(seconds: 3), () {
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => StartScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            'assets/images/MG-background.jpg', // Replace with your image path
            fit: BoxFit.cover,
          ),
          // Fade-in image
          Center(
            child: AnimatedOpacity(
              opacity: _opacity,
              duration:
                  Duration(seconds: 2), // The duration for the fade-in effect
              child: Image.asset(
                'assets/images/MG-logo.png', // Replace with your image path
                width: 100, // Adjust size as needed
                height: 100, // Adjust size as needed
              ),
            ),
          ),
        ],
      ),
    );
  }
}
