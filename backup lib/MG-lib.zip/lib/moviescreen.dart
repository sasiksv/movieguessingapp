import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:movieguessingapp/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';

class MoviesScreen extends StatefulWidget {
  final String genre;
  final int startIndex;

  const MoviesScreen({super.key, required this.genre, this.startIndex = 0});

  @override
  _MoviesScreenState createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen> {
  List<List<dynamic>> _questions = [];
  int _currentQuestionIndex = 0;
  String _selectedOption = "";
  bool _isAnswered = false; // To track if the user has submitted an answer

  @override
  void initState() {
    super.initState();
    _loadProgress();
    loadCSV();
  }

  Future<void> loadCSV() async {
    final data = await rootBundle.loadString('assets/movies.csv');
    List<List<dynamic>> csvData = const CsvToListConverter().convert(data);
    setState(() {
      _questions =
          csvData.where((question) => question[6] == widget.genre).toList();
    });
  }

  Future<void> _loadProgress() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _currentQuestionIndex =
          prefs.getInt('progress_${widget.genre}') ?? widget.startIndex;
    });
  }

  Future<void> _saveCurrentIndex() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('progress_${widget.genre}', _currentQuestionIndex);
  }

  void _selectOption(String option) {
    if (!_isAnswered) {
      setState(() {
        _selectedOption = option;
      });
    }
  }

  void _goToNextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _selectedOption = "";
        _isAnswered = false; // Reset answer status for the next question
      });
      _saveCurrentIndex();
    }
  }

  void _submitAnswer() {
    if (_selectedOption.isEmpty) {
      // Show an alert dialog if no option is selected
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: const Text('Please select an option!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Validate the selected option
      setState(() {
        _isAnswered = true; // Mark as answered
      });

      if (_selectedOption == _questions[_currentQuestionIndex][5]) {
        _goToNextQuestion();
      } else {
        // Show the alert box and make it non-dismissible
        showDialog(
          context: context,
          barrierDismissible: false, // Prevent dismissing by touching outside
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: Colors.white,
              content: Text(
                  'Correct answer: ${_questions[_currentQuestionIndex][5]}'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _goToNextQuestion();
                  },
                  child: const Text(
                    'NEXT',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
              ],
            );
          },
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_questions.isEmpty) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    var question = _questions[_currentQuestionIndex];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(title: ''),
      body: Column(
        children: [
          // Display selected genre below the AppBar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              '${widget.genre} Genre Quiz',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Quote Box
                  Container(
                    width: double.infinity, // Adjust width as needed
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.blueGrey[50],
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 4.0,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    constraints: const BoxConstraints(
                      maxHeight: 150, // Adjust height as needed
                    ),
                    child: Center(
                      child: Text(
                        question[0],
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Options
                  Center(
                    child: Column(
                      children: [
                        for (int i = 1; i <= 4; i++)
                          GestureDetector(
                            onTap: () => _selectOption(question[i]),
                            child: Container(
                              width: 300, // Common width for all boxes
                              height: 70, // Common height for all boxes
                              margin: const EdgeInsets.only(
                                  bottom: 10), // Space between options
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8.0, vertical: 12.0),
                              decoration: BoxDecoration(
                                color: _selectedOption == question[i]
                                    ? Colors.blue[100]
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Colors.grey),
                              ),
                              child: Center(
                                child: Text(
                                  question[i],
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Submit Button
                  GestureDetector(
                    onTap: _isAnswered
                        ? null // Disable submit button if already answered
                        : _submitAnswer,
                    child: Container(
                      width: 200, // Adjust width as needed
                      height: 60, // Adjust height as needed
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: _isAnswered
                              ? [
                                  Colors.grey,
                                  Colors.grey
                                ] // Greyed-out if answered
                              : [Colors.blue, Colors.lightBlueAccent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 4.0,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'SUBMIT',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
