import 'package:flutter/material.dart';
import 'splashscreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;

  CustomAppBar({required this.title, this.actions});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text('Movie Name Guessing'),
      actions: actions,
      backgroundColor: Colors.blueAccent, // Customize the AppBar color
      foregroundColor: Colors.black, // Customize the text color
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
